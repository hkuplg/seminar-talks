{-# OPTIONS_GHC -fno-warn-missing-signatures
                -fno-warn-unused-binds
                -fno-warn-unused-matches #-}

module Person where

import Mixin

data Person = Person { name :: String, age :: Int, sayHello :: IO () }

someOneM super this =
  Person { name = "SomeOne"
         , age = 1
         , sayHello = putStrLn ("Hi, I'm " ++ name this) }

tomM super this =
  Person { name = "Tom"
         , age = 21
         , sayHello = sayHello super }

jerryM super this =
  Person { name = "Jerry"
         , age = age super
         , sayHello = sayHello super }

tom   = new (tomM   `extends` someOneM)
jerry = new (jerryM `extends` someOneM)