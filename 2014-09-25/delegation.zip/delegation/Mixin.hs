{-# OPTIONS_GHC -fno-warn-missing-signatures
                -fno-warn-unused-binds
                -fno-warn-unused-matches #-}

module Mixin where

import Prelude hiding (even, odd)

type Mixin s = s -> s -> s

new :: Mixin s -> s
new f = let r = f r r in r

fix f = let x = f x in x

compose :: (s -> s) -> (s -> s) -> (s -> s)
f `compose` g = \this -> f (g this)

fib super this = \n -> if n == 1 || n == 2
                          then 1
                          else this (n - 1) + this (n - 2)

fix2 super this = \n -> if n == 30
                           then 832040
                           else super n

fastFib = fix2 `extends` fib

extends :: Mixin s -> Mixin s -> Mixin s
f `extends` g = \super this -> f (g super this) this