{-# OPTIONS_GHC -fno-warn-missing-signatures
                -fno-warn-unused-binds
                -fno-warn-unused-matches #-}

module EvenOdd where

import Mixin

import Prelude hiding (even, odd)

data EvenOdd = EvenOdd { even :: Int -> Bool, odd :: Int -> Bool }

evenOddMixin super this
  = EvenOdd { even = \n -> if n == 0 then True  else odd this (n - 1)
            , odd  = \n -> if n == 0 then False else even this (n - 1) }

evenOdd = new evenOddMixin