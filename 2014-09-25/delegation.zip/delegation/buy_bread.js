var mom = {};
var me = {};

mom.goToWork = function() {
  skewer.log("Going to work!");
};

me.buyBread = function() {
  skewer.log("Bought some bread!");
};

mom.goToWork();
me.buyBread();

// // Mom delegates some tasks to me.
mom.__proto__ = me;

mom.buyBread();