var EvenOdd = function() {
  this.even = function(n) { if (n == 0) return true;  else return this.odd(n-1); };
  this.odd  = function(n) { if (n == 0) return false; else return this.even(n-1); };
};

var even_odd = new EvenOdd();