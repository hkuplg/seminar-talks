import java.util.Random;

class SomeOne {
    String name = "SomeOne";
    void sayHello() { System.out.println("I'm " + this.name); }
}

class Tom extends SomeOne {
    String name = "Tom";
    void sayHello() { System.out.println("I am " + this.name); }
}

class Jerry extends SomeOne {
    String name = "Jerry";
    void sayHello() { System.out.println("I am " + this.name); }
}

class Person {
    public static void main(String[] args) {
    SomeOne tom;//new Tom();

    if (new Random().nextInt(2) % 2 == 0) {
        tom = new Tom();
        System.out.println(tom.name);
        tom.sayHello();
    } else {
        tom = new Jerry();
        System.out.println(tom.name);
        tom.sayHello();
    }
}
}