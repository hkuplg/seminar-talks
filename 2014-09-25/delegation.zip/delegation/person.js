var SomeOne = function() {
  this.name = "SomeOne";
  this.age  = 1;
  this.sayHello = function () {
    skewer.log("Hi, I'm " + this.name);
  };
  return this;
};

var Tom = function() {
  this.name = "Tom";
  this.age = 21;
  this.sayHello = this.sayHello;
  return this;
};

var Jerry = function() {
  this.name = "Jerry";
  this.age = this.age;
  this.sayHello = this.goToWork;
  return this;
};

Tom.prototype = new SomeOne();
var tom = new Tom();

Jerry.prototype = new SomeOne();
var jerry = new Jerry();